#!/bin/bash
###############################################################################
# user-data.sh  (EC2 bootstrap untuk Streamlit credit score)
#
# Script ini otomatis dijalankan SEKALI waktu instance EC2 pertama kali nyala.
# Fungsinya: install Python + Streamlit + boto3, nulis app-nya, lalu jalanin
# Streamlit sebagai service di port 8501 supaya bisa diakses via URL public.
#
# App yang dijalanin = versi yang MANGGIL SageMaker endpoint (bukan model lokal).
# Jadi: EC2 = tampilan web, SageMaker endpoint = model-nya.
#
# ---- SEBELUM LAUNCH, PERHATIKAN INI (Learner Lab): ----
#  1. Attach IAM instance profile "LabInstanceProfile" ke instance
#     (Advanced details -> IAM instance profile). Ini yang bikin EC2 punya izin
#     manggil SageMaker endpoint tanpa perlu access key.
#  2. Security group: buka inbound port 8501 (Custom TCP) dari 0.0.0.0/0,
#     dan port 22 (SSH) dari IP kamu.
#  3. Ganti ENDPOINT_NAME di bawah kalau nama endpoint kamu beda.
#  4. Endpoint SageMaker harus dalam status InService (belum dihapus).
###############################################################################

set -eux

# ====== KONFIGURASI (edit kalau perlu) ======
ENDPOINT_NAME="credit-score-ep3"
REGION="us-east-1"
# ============================================

# --- deteksi package manager & user default (Amazon Linux vs Ubuntu) ---
if command -v dnf >/dev/null 2>&1; then
    PKG="dnf"; APP_USER="ec2-user"
elif command -v yum >/dev/null 2>&1; then
    PKG="yum"; APP_USER="ec2-user"
else
    PKG="apt-get"; APP_USER="ubuntu"
fi

APP_DIR="/home/${APP_USER}/creditapp"
mkdir -p "${APP_DIR}"

# --- install python + pip ---
if [ "${PKG}" = "apt-get" ]; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y python3 python3-pip
else
    ${PKG} install -y python3 python3-pip
fi

pip3 install --upgrade pip
pip3 install streamlit boto3

# --- tulis app Streamlit yang manggil SageMaker endpoint ---
cat > "${APP_DIR}/app_sagemaker.py" <<'PYEOF'
import os
import json

import boto3
import streamlit as st

st.set_page_config(page_title="Credit Score (SageMaker)", page_icon="💳",
                   layout="centered")

# konfigurasi diambil dari environment (di-set lewat systemd service)
DEFAULT_ENDPOINT = os.environ.get("ENDPOINT_NAME", "credit-score-ep2")
DEFAULT_REGION = os.environ.get("AWS_REGION", "us-east-1")

st.sidebar.header("Konfigurasi Endpoint")
endpoint_name = st.sidebar.text_input("Endpoint name", DEFAULT_ENDPOINT)
region = st.sidebar.text_input("Region", DEFAULT_REGION)


@st.cache_resource
def get_runtime(region_name):
    return boto3.client("sagemaker-runtime", region_name=region_name)


def call_endpoint(payload: dict):
    runtime = get_runtime(region)
    resp = runtime.invoke_endpoint(
        EndpointName=endpoint_name,
        ContentType="application/json",
        Body=json.dumps(payload),
    )
    result = json.loads(resp["Body"].read())[0]
    return result["label"], result.get("proba", {})


TEST_CASES = {
    "Good": {
        "Age": 29, "Occupation": "Doctor", "Annual_Income": 18002.67,
        "Monthly_Inhand_Salary": 1430.22, "Num_Bank_Accounts": 6,
        "Num_Credit_Card": 3, "Interest_Rate": 10, "Num_of_Loan": 3,
        "Delay_from_due_date": 27, "Num_of_Delayed_Payment": 15,
        "Changed_Credit_Limit": 0.94, "Num_Credit_Inquiries": 6,
        "Credit_Mix": "Good", "Outstanding_Debt": 698.05,
        "Credit_Utilization_Ratio": 29.98, "Credit_History_Months": 339,
        "Payment_of_Min_Amount": "No", "Total_EMI_per_month": 34.03,
        "Amount_invested_monthly": 32.73,
        "Payment_Behaviour": "High_spent_Large_value_payments",
        "Monthly_Balance": 316.26, "Num_Loan_Types": 3,
    },
    "Standard": {
        "Age": 29, "Occupation": "Musician", "Annual_Income": 142081.48,
        "Monthly_Inhand_Salary": 11771.12, "Num_Bank_Accounts": 6,
        "Num_Credit_Card": 6, "Interest_Rate": 15, "Num_of_Loan": 3,
        "Delay_from_due_date": 29, "Num_of_Delayed_Payment": 20,
        "Changed_Credit_Limit": 8.21, "Num_Credit_Inquiries": 4,
        "Credit_Mix": "Standard", "Outstanding_Debt": 932.32,
        "Credit_Utilization_Ratio": 28.41, "Credit_History_Months": 324,
        "Payment_of_Min_Amount": "No", "Total_EMI_per_month": 180.62,
        "Amount_invested_monthly": 423.96,
        "Payment_Behaviour": "Low_spent_Small_value_payments",
        "Monthly_Balance": 862.53, "Num_Loan_Types": 3,
    },
    "Poor": {
        "Age": 46, "Occupation": "Writer", "Annual_Income": 83823.22,
        "Monthly_Inhand_Salary": 6841.27, "Num_Bank_Accounts": 3,
        "Num_Credit_Card": 5, "Interest_Rate": 11, "Num_of_Loan": 1,
        "Delay_from_due_date": 6, "Num_of_Delayed_Payment": 9,
        "Changed_Credit_Limit": 10.31, "Num_Credit_Inquiries": 0,
        "Credit_Mix": "Good", "Outstanding_Debt": 184.71,
        "Credit_Utilization_Ratio": 37.6, "Credit_History_Months": 245,
        "Payment_of_Min_Amount": "No", "Total_EMI_per_month": 41.3,
        "Amount_invested_monthly": 451.55,
        "Payment_Behaviour": "Low_spent_Medium_value_payments",
        "Monthly_Balance": 471.27, "Num_Loan_Types": 1,
    },
}

OCCUPATIONS = ["Scientist", "Teacher", "Engineer", "Entrepreneur", "Developer",
               "Lawyer", "Media_Manager", "Doctor", "Journalist", "Manager",
               "Accountant", "Musician", "Mechanic", "Writer", "Architect"]
CREDIT_MIX = ["Good", "Standard", "Bad"]
PAY_MIN = ["Yes", "No", "NM"]
PAY_BEHAVIOUR = ["High_spent_Large_value_payments", "High_spent_Medium_value_payments",
                 "High_spent_Small_value_payments", "Low_spent_Large_value_payments",
                 "Low_spent_Medium_value_payments", "Low_spent_Small_value_payments"]

st.title("💳 Credit Score Prediction")
st.caption(f"Prediksi lewat SageMaker endpoint `{endpoint_name}` (region {region}).")

st.sidebar.header("Preset Test Case")
preset = st.sidebar.selectbox("Isi otomatis dengan contoh:",
                              ["— manual —"] + list(TEST_CASES.keys()))
d = TEST_CASES.get(preset, {})


def g(key, default):
    return d.get(key, default)


st.subheader("Data Demografi & Pekerjaan")
c1, c2 = st.columns(2)
age = c1.number_input("Age", 18, 100, int(g("Age", 30)))
occupation = c2.selectbox("Occupation", OCCUPATIONS,
                          index=OCCUPATIONS.index(g("Occupation", "Engineer"))
                          if g("Occupation", "Engineer") in OCCUPATIONS else 0)

st.subheader("Pendapatan")
c1, c2 = st.columns(2)
annual_income = c1.number_input("Annual Income", 0.0, value=float(g("Annual_Income", 50000.0)))
monthly_salary = c2.number_input("Monthly Inhand Salary", 0.0,
                                 value=float(g("Monthly_Inhand_Salary", 4000.0)))

st.subheader("Akun & Pinjaman")
c1, c2, c3 = st.columns(3)
num_bank = c1.number_input("Num Bank Accounts", 0, 20, int(g("Num_Bank_Accounts", 5)))
num_card = c2.number_input("Num Credit Card", 0, 20, int(g("Num_Credit_Card", 5)))
interest = c3.number_input("Interest Rate", 0, 50, int(g("Interest_Rate", 14)))
c1, c2, c3 = st.columns(3)
num_loan = c1.number_input("Num of Loan", 0, 20, int(g("Num_of_Loan", 3)))
num_loan_types = c2.number_input("Num Loan Types", 0, 12, int(g("Num_Loan_Types", 3)))
outstanding = c3.number_input("Outstanding Debt", 0.0, value=float(g("Outstanding_Debt", 1000.0)))

st.subheader("Riwayat Pembayaran")
c1, c2, c3 = st.columns(3)
delay = c1.number_input("Delay from due date", -10, 200, int(g("Delay_from_due_date", 15)))
num_delayed = c2.number_input("Num of Delayed Payment", 0, 100, int(g("Num_of_Delayed_Payment", 10)))
inquiries = c3.number_input("Num Credit Inquiries", 0, 100, int(g("Num_Credit_Inquiries", 4)))
c1, c2, c3 = st.columns(3)
changed_limit = c1.number_input("Changed Credit Limit", value=float(g("Changed_Credit_Limit", 8.0)))
util = c2.number_input("Credit Utilization Ratio", 0.0, 100.0, float(g("Credit_Utilization_Ratio", 32.0)))
history_months = c3.number_input("Credit History (months)", 0, 600, int(g("Credit_History_Months", 200)))

st.subheader("Lainnya")
c1, c2 = st.columns(2)
credit_mix = c1.selectbox("Credit Mix", CREDIT_MIX,
                          index=CREDIT_MIX.index(g("Credit_Mix", "Standard")))
pay_min = c2.selectbox("Payment of Min Amount", PAY_MIN,
                       index=PAY_MIN.index(g("Payment_of_Min_Amount", "No")))
c1, c2 = st.columns(2)
total_emi = c1.number_input("Total EMI per month", 0.0, value=float(g("Total_EMI_per_month", 100.0)))
invested = c2.number_input("Amount invested monthly", 0.0, value=float(g("Amount_invested_monthly", 200.0)))
balance = st.number_input("Monthly Balance", value=float(g("Monthly_Balance", 400.0)))
behaviour = st.selectbox("Payment Behaviour", PAY_BEHAVIOUR,
                         index=PAY_BEHAVIOUR.index(g("Payment_Behaviour", PAY_BEHAVIOUR[0]))
                         if g("Payment_Behaviour", PAY_BEHAVIOUR[0]) in PAY_BEHAVIOUR else 0)

if st.button("Prediksi Credit Score", type="primary", use_container_width=True):
    payload = {
        "Age": age, "Occupation": occupation, "Annual_Income": annual_income,
        "Monthly_Inhand_Salary": monthly_salary, "Num_Bank_Accounts": num_bank,
        "Num_Credit_Card": num_card, "Interest_Rate": interest, "Num_of_Loan": num_loan,
        "Delay_from_due_date": delay, "Num_of_Delayed_Payment": num_delayed,
        "Changed_Credit_Limit": changed_limit, "Num_Credit_Inquiries": inquiries,
        "Credit_Mix": credit_mix, "Outstanding_Debt": outstanding,
        "Credit_Utilization_Ratio": util, "Credit_History_Months": history_months,
        "Payment_of_Min_Amount": pay_min, "Total_EMI_per_month": total_emi,
        "Amount_invested_monthly": invested, "Payment_Behaviour": behaviour,
        "Monthly_Balance": balance, "Num_Loan_Types": num_loan_types,
    }
    try:
        with st.spinner("Memanggil SageMaker endpoint..."):
            label, proba = call_endpoint(payload)
        color = {"Good": "green", "Standard": "orange", "Poor": "red"}.get(label, "gray")
        st.markdown(f"### Hasil: :{color}[{label}]")
        if proba:
            st.write("Probabilitas per kelas:")
            for cls in ["Poor", "Standard", "Good"]:
                if cls in proba:
                    st.progress(proba[cls], text=f"{cls} — {proba[cls]:.1%}")
    except Exception as e:
        st.error(f"Gagal manggil endpoint: {e}")
        st.info("Cek: endpoint masih InService? Nama & region bener? "
                "Instance profile (LabInstanceProfile) ke-attach?")
PYEOF

chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"

# --- bikin systemd service biar Streamlit jalan terus & auto-restart ---
STREAMLIT_BIN="$(command -v streamlit)"
cat > /etc/systemd/system/creditapp.service <<SERVICEEOF
[Unit]
Description=Credit Score Streamlit App
After=network.target

[Service]
User=${APP_USER}
WorkingDirectory=${APP_DIR}
Environment=ENDPOINT_NAME=${ENDPOINT_NAME}
Environment=AWS_REGION=${REGION}
Environment=AWS_DEFAULT_REGION=${REGION}
ExecStart=${STREAMLIT_BIN} run ${APP_DIR}/app_sagemaker.py --server.port 8501 --server.address 0.0.0.0 --server.headless true
Restart=always

[Install]
WantedBy=multi-user.target
SERVICEEOF

systemctl daemon-reload
systemctl enable creditapp.service
systemctl start creditapp.service

echo "Setup selesai. Streamlit jalan di port 8501."
