"""
inference.py  (entry point buat SageMaker endpoint)
---------------------------------------------------
Script ini dipanggil otomatis sama container SageMaker waktu endpoint jalan.
Ada 4 fungsi standar yang dikenali SageMaker:

  model_fn   : load artefak model (dipanggil sekali pas container start)
  input_fn   : parse request yang masuk (JSON) jadi DataFrame
  predict_fn : jalanin preprocessing + prediksi
  output_fn  : format hasil balik jadi JSON

Endpoint nerima JSON, bisa satu nasabah (dict) atau banyak (list of dict),
mengembalikan label + probabilitas tiap kelas.
"""

import os
import json
import pickle

import pandas as pd

# DataPreprocessor dibutuhkan pas unpickle preprocessor.pkl.
# pipeline.py ikut dikirim di folder code/ jadi bisa di-import.
from pipeline import DataPreprocessor  # noqa: F401


def model_fn(model_dir):
    """Load model + preprocessor dari folder artefak."""
    with open(os.path.join(model_dir, "best_model.pkl"), "rb") as f:
        model = pickle.load(f)
    with open(os.path.join(model_dir, "preprocessor.pkl"), "rb") as f:
        pre = pickle.load(f)
    return {"model": model, "pre": pre}


def input_fn(request_body, request_content_type):
    """Ubah request body jadi DataFrame."""
    if request_content_type == "application/json":
        data = json.loads(request_body)
        # boleh kirim satu dict, atau list of dict buat batch
        if isinstance(data, dict):
            # kalau formatnya {"instances": [...]} juga dihandle
            if "instances" in data:
                data = data["instances"]
            else:
                data = [data]
        return pd.DataFrame(data)
    raise ValueError(f"Content type tidak didukung: {request_content_type}")


def predict_fn(input_df, artifacts):
    """Preprocessing + prediksi. Balikin list hasil per baris."""
    model = artifacts["model"]
    pre = artifacts["pre"]
    classes = list(pre.label_encoder.classes_)

    X = pre.transform(input_df)
    preds = model.predict(X)
    labels = pre.decode_target(preds)

    results = []
    if hasattr(model, "predict_proba"):
        probas = model.predict_proba(X)
        for i, label in enumerate(labels):
            results.append({
                "label": str(label),
                "proba": {classes[j]: round(float(probas[i][j]), 4)
                          for j in range(len(classes))},
            })
    else:
        results = [{"label": str(l)} for l in labels]
    return results


def output_fn(prediction, accept):
    """Format output jadi JSON."""
    return json.dumps(prediction), "application/json"
